
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'tvergho',
  applicationName: 'nchtr-io',
  appUid: '7nhTDrWmRDbVZjKM5M',
  orgUid: '11njjSGwvm2ch6ljJV',
  deploymentUid: '5d190910-8d8e-4eea-a1b7-b00355124ce7',
  serviceName: 'nchtr-io',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '3.6.16',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'nchtr-io-dev-getUploadUrl', timeout: 6 };

try {
  const userHandler = require('./getUploadUrl.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}